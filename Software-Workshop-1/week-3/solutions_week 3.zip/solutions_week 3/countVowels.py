input_string = input("enter input string")
vowels = "aeiouAEIOU"
vowel_count = 0
result_string = ""

for char in input_string:
    if char in vowels:
        vowel_count += 1
    else:
        result_string += char

print("There are ", vowel_count," vowels.")
print("The string without vowels is:", result_string)